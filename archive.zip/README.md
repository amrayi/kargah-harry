I'm 18 years old and I have a glass and long black hare. I like coffee.
I am really into studing abroad.
